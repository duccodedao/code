<p>&nbsp;</p><div class="separator" style="clear: both; text-align: center;"><a href="login.php" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" data-original-height="419" data-original-width="693" height="386" src="img/baner2.png" width="640" /></a> 

<center class='mt-2'><small>Bấm vào đây 👆</small></center>


</div><br /><p></p>